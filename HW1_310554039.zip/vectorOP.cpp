#include "PPintrin.h"

// implementation of absSerial(), but it is vectorized using PP intrinsics
void absVector(float *values, float *output, int N)
{
  __pp_vec_float x;
  __pp_vec_float result;
  __pp_vec_float zero = _pp_vset_float(0.f);
  __pp_mask maskAll, maskIsNegative, maskIsNotNegative;

  //  Note: Take a careful look at this loop indexing.  This example
  //  code is not guaranteed to work when (N % VECTOR_WIDTH) != 0.
  //  Why is that the case?
  for (int i = 0; i < N; i += VECTOR_WIDTH)
  {

    // All ones
    maskAll = _pp_init_ones();

    // All zeros
    maskIsNegative = _pp_init_ones(0);

    // Load vector of values from contiguous memory addresses
    _pp_vload_float(x, values + i, maskAll); // x = values[i];

    // Set mask according to predicate
    _pp_vlt_float(maskIsNegative, x, zero, maskAll); // if (x < 0) {

    // Execute instruction using mask ("if" clause)
    _pp_vsub_float(result, zero, x, maskIsNegative); //   output[i] = -x;

    // Inverse maskIsNegative to generate "else" mask
    maskIsNotNegative = _pp_mask_not(maskIsNegative); // } else {

    // Execute instruction ("else" clause)
    _pp_vload_float(result, values + i, maskIsNotNegative); //   output[i] = x; }

    // Write results back to memory
    _pp_vstore_float(output + i, result, maskAll);
  }
}

void clampedExpVector(float *values, int *exponents, float *output, int N)
{
  //
  // PP STUDENTS TODO: Implement your vectorized version of
  // clampedExpSerial() here.
  //
  // Your solution should work for any value of
  // N and VECTOR_WIDTH, not just when VECTOR_WIDTH divides N
  //
  __pp_vec_float base  ;
  __pp_vec_int   exp   ;
  __pp_vec_float result;
  __pp_vec_float maxValue = _pp_vset_float(9.999999f) ;
  __pp_vec_int zero = _pp_vset_int(0);
  __pp_vec_int one = _pp_vset_int(1); 
  __pp_vec_int two = _pp_vset_int(2); 
  __pp_vec_int temp = _pp_vset_int(0); 
  
  __pp_mask maskImp ;
  __pp_mask maskNeedImp;
  __pp_mask maskIsFinish;
  __pp_mask maskIsEven  ;
  __pp_mask maskIsOdd   ;
  __pp_mask maskIsZero  ;
  __pp_mask maskTemp    ;
  
  
  for (int i = 0; i < N; i += VECTOR_WIDTH)
  {
      result = _pp_vset_float(1.0f);
      if (i + VECTOR_WIDTH > N){
        int M = N % VECTOR_WIDTH;
        maskImp = _pp_init_ones(M);
        maskNeedImp = _pp_init_ones(M);
      }else{
        maskImp = _pp_init_ones();
        maskNeedImp = _pp_init_ones();
      }
      maskIsEven  = _pp_init_ones(0);
      maskIsOdd   = _pp_init_ones(0);
      
      _pp_vload_float(base, values + i, maskImp);
      _pp_vload_int(exp, exponents + i, maskImp);
      
      _pp_veq_int(maskIsZero, exp, zero, maskImp);
      maskTemp = _pp_mask_not(maskIsZero);
      maskNeedImp = _pp_mask_and(maskTemp, maskNeedImp);
      maskIsFinish = _pp_mask_not(maskNeedImp);
      
      do {
      _pp_vdiv_int(temp, exp, two, maskNeedImp);
      _pp_vmult_int(temp, temp, two, maskNeedImp);
      _pp_veq_int(maskIsEven, exp, temp, maskNeedImp);
      maskIsOdd = _pp_mask_not(maskIsEven);
      
      maskTemp = _pp_mask_and(maskIsOdd, maskNeedImp);
      _pp_vmult_float(result, result, base, maskTemp);
      
      _pp_veq_int(maskIsFinish, exp, one, maskNeedImp);
      maskNeedImp = _pp_mask_not(maskIsFinish);
      
      // values = values * values
      _pp_vmult_float(base, base, base, maskNeedImp);
      
      // exponents = exponents / 2
      _pp_vdiv_int(exp, exp, two, maskNeedImp);
      
      }while (_pp_cntbits(maskIsFinish) != VECTOR_WIDTH);
      
      // 若答案大於9.999999，寫入9.999999
      maskTemp = _pp_init_ones(0);
      _pp_vgt_float(maskTemp, result, maxValue, maskImp);
      maskTemp = _pp_mask_and(maskTemp, maskImp);
      _pp_vset_float(result, 9.999999f, maskTemp);
    
      // Write results back to memory
      _pp_vstore_float(output + i, result, maskImp);
  }
}

// returns the sum of all elements in values
// You can assume N is a multiple of VECTOR_WIDTH
// You can assume VECTOR_WIDTH is a power of 2
float arraySumVector(float *values, int N) 
{
  __pp_vec_float x = _pp_vset_float(0.f);
  __pp_vec_float result = _pp_vset_float(0.f);
  __pp_mask maskAll = _pp_init_ones(); 
  __pp_mask maskAdd; 
  //
  // PP STUDENTS TODO: Implement your vectorized version of arraySumSerial here
  //
  for (int i = 0; i < N; i += VECTOR_WIDTH)
  {
    
    // x = values[i];
    _pp_vload_float(x, values + i, maskAll);
    
    // result = result + x
    _pp_vadd_float(result, result, x, maskAll);
  }
  
  for (int i = VECTOR_WIDTH; i > 1; i /= 2)
  {
    // 留前面i個值
    maskAdd = _pp_init_ones(i);
    maskAdd = _pp_mask_not(maskAdd);
    _pp_vset_float(result, 0.f, maskAdd);
    
    _pp_hadd_float(result, result);
    _pp_interleave_float(result, result);

    if (i % 2 == 1)
    {
      i += 1;
    }
  }
  
  return result.value[0];
}
